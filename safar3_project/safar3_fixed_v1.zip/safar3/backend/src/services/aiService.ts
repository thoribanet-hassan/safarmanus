import axios from 'axios';
import { config } from '../config/env.js';

interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export async function chatWithAI(messages: ChatMessage[]): Promise<string> {
  try {
    const response = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: 'gpt-4',
        messages: [
          {
            role: 'system',
            content: `أنت مساعد سفر ذكي اسمه "عقل سفر". تساعد المستخدمين في:
- البحث عن رحلات طيران وفنادق
- تقديم نصائح السفر
- الإجابة على أسئلة السفر
- اقتراح وجهات سياحية

كن ودوداً ومفيداً. أجب باللغة العربية إذا كان السؤال بالعربية، وبالإنجليزية إذا كان السؤال بالإنجليزية.`,
          },
          ...messages,
        ],
        temperature: 0.7,
        max_tokens: 500,
      },
      {
        headers: {
          'Authorization': `Bearer ${config.openai.apiKey}`,
          'Content-Type': 'application/json',
        },
      }
    );

    return response.data.choices[0].message.content;
  } catch (error: any) {
    console.error('AI chat error:', error.response?.data || error.message);
    throw new Error('Failed to get AI response');
  }
}

export async function parseSmartSearch(query: string): Promise<{
  origin?: string;
  destination?: string;
  departureDate?: string;
  returnDate?: string;
  passengers?: number;
}> {
  try {
    const response = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: 'gpt-4',
        messages: [
          {
            role: 'system',
            content: `أنت محلل نصوص للبحث عن رحلات الطيران. استخرج المعلومات التالية من نص المستخدم:
- origin: رمز المطار للمغادرة (IATA code)
- destination: رمز المطار للوصول (IATA code)
- departureDate: تاريخ المغادرة بصيغة YYYY-MM-DD
- returnDate: تاريخ العودة بصيغة YYYY-MM-DD (إن وجد)
- passengers: عدد المسافرين

أرجع النتيجة بصيغة JSON فقط، بدون أي نص إضافي.`,
          },
          {
            role: 'user',
            content: query,
          },
        ],
        temperature: 0.3,
        max_tokens: 200,
      },
      {
        headers: {
          'Authorization': `Bearer ${config.openai.apiKey}`,
          'Content-Type': 'application/json',
        },
      }
    );

    const content = response.data.choices[0].message.content;
    return JSON.parse(content);
  } catch (error: any) {
    console.error('Smart search parsing error:', error.response?.data || error.message);
    throw new Error('Failed to parse search query');
  }
}
