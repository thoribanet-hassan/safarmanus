import { useState } from 'react';
import { Search, Loader, MessageSquare, Sparkles, Target, Bell, ArrowRight } from 'lucide-react';
import { useLanguage} from '../contexts/LanguageContext';
import { searchFlights, createFlightSniper, createFlightPriceMonitor, FlightOffer, FlightSearchParams, FlightSniperParams } from '../services/flightService';
import './FlightsPage.css';

type TripType = 'one-way' | 'round-trip' | 'multi-city';

export const FlightsPage = () => {
    const { t } = useLanguage();
    const [tripType, setTripType] = useState<TripType>('round-trip');
    const [searchParams, setSearchParams] = useState<FlightSearchParams>({
        origin: '',
        destination: '',
        departureDate: '',
        returnDate: '',
        adults: 1,
        cabinClass: 'ECONOMY'
    });

    const [sniperParams, setSniperParams] = useState<FlightSniperParams>({
        origin: '',
        destination: '',
        maxPrice: 1000,
        departureDate: '',
        returnDate: '',
        durationHours: 24,
        frequencyMinutes: 60
    });

    const [showSmartSearchModal, setShowSmartSearchModal] = useState(false);
    const [showSniperModal, setShowSniperModal] = useState(false);
    const [showMonitorModal, setShowMonitorModal] = useState(false);
    const [smartQuery, setSmartQuery] = useState('');

    const [results, setResults] = useState<FlightOffer[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string>('');
    const [successMessage, setSuccessMessage] = useState<string>('');
    const [parsedIntent, setParsedIntent] = useState<string>('');

    // --- Smart Search Logic ---
    const handleSmartSearch = async () => {
        if (!smartQuery.trim()) {
            setError(t('smart_search_placeholder'));
            return;
        }

        setIsLoading(true);
        setError('');
        setSuccessMessage('');

        // Mock parsing logic for now
        setParsedIntent(t('search_completed'));

        setTimeout(() => {
            setIsLoading(false);
            setShowSmartSearchModal(false);
            // In a real app, this would call an AI service to parse and then search
            setError(t('service_suspended'));
        }, 1500);
    };

    // --- Sniper Logic ---
    const handleSniperSubmit = async () => {
        if (!sniperParams.origin || !sniperParams.destination) {
            setError('يرجى تحديد وجهة المغادرة والوصول');
            return;
        }

        setIsLoading(true);
        setError('');
        setSuccessMessage('');

        try {
            const response = await createFlightSniper({
                ...sniperParams,
                departureDate: searchParams.departureDate || new Date().toISOString().split('T')[0]
            });

            if (response.success) {
                setSuccessMessage(response.message);
                setShowSniperModal(false);
            } else {
                setError('حدث خطأ أثناء تفعيل صائد الرحلات');
            }
        } catch (err) {
            setError('الخدمة معلّقة مؤقتاً');
        } finally {
            setIsLoading(false);
        }
    };

    // --- Monitor Logic ---
    const handleMonitorSubmit = async () => {
        if (!searchParams.origin || !searchParams.destination || !searchParams.departureDate) {
            setError('يرجى ملء بيانات البحث الأساسية أولاً');
            return;
        }

        setIsLoading(true);
        setError('');
        setSuccessMessage('');

        try {
            const response = await createFlightPriceMonitor({
                origin: searchParams.origin,
                destination: searchParams.destination,
                departureDate: searchParams.departureDate,
                returnDate: searchParams.returnDate
            });

            setSuccessMessage(response.message);
            setShowMonitorModal(false);
        } catch (err) {
            setError(t('service_suspended'));
        } finally {
            setIsLoading(false);
        }
    };

    // --- Classic Search Logic ---
    const handleSearch = async () => {
        if (!searchParams.origin || !searchParams.destination || !searchParams.departureDate) {
            setError(t('please_fill_all_fields'));
            return;
        }

        setIsLoading(true);
        setError('');
        setResults([]);

        try {
            const data = await searchFlights(searchParams);
            if (data.length === 0) {
                setError(t('service_suspended'));
            } else {
                setResults(data);
            }
        } catch (err) {
            setError(err instanceof Error ? err.message : t('service_suspended'));
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="flights-page">
            <div className="flights-hero">
                <h1 className="animate-fade-in">✈️ {t('flights_title')}</h1>
                <p>{t('flights_subtitle')}</p>
            </div>

            {/* نموذج البحث البسيط */}
            <div className="search-container">
                <div className="simple-search-form glass-card">
                    <h3>{t('flight_info')}</h3>

                    {/* Trip Type Selection */}
                    <div className="trip-type-selector mb-6 flex gap-4 border-b border-white/10 pb-4">
                        <label className={`cursor-pointer flex items-center gap-2 ${tripType === 'one-way' ? 'text-blue-400 font-bold' : 'text-white/70'}`}>
                            <input
                                type="radio"
                                name="tripType"
                                checked={tripType === 'one-way'}
                                onChange={() => setTripType('one-way')}
                                className="accent-blue-500"
                            />
                            {t('trip_type_one_way')}
                        </label>
                        <label className={`cursor-pointer flex items-center gap-2 ${tripType === 'round-trip' ? 'text-blue-400 font-bold' : 'text-white/70'}`}>
                            <input
                                type="radio"
                                name="tripType"
                                checked={tripType === 'round-trip'}
                                onChange={() => setTripType('round-trip')}
                                className="accent-blue-500"
                            />
                            {t('trip_type_round_trip')}
                        </label>
                        <label className={`cursor-pointer flex items-center gap-2 ${tripType === 'multi-city' ? 'text-blue-400 font-bold' : 'text-white/70'}`}>
                            <input
                                type="radio"
                                name="tripType"
                                checked={tripType === 'multi-city'}
                                onChange={() => setTripType('multi-city')}
                                className="accent-blue-500"
                            />
                            {t('multi_city')}
                        </label>
                    </div>

                    {tripType === 'multi-city' ? (
                        <div className="multi-city-container">
                            {/* For now, just a placeholder or basic implementation */}
                            <div className="p-4 bg-white/5 rounded-lg border border-white/10 mb-4">
                                <p className="text-yellow-400 text-sm mb-2">🚧 {t('multi_city_under_development')}</p>
                                <div className="input-row">
                                    <div className="input-group">
                                        <label>{t('trip_1_from')}</label>
                                        <input type="text" className="simple-input" placeholder="JED" />
                                    </div>
                                    <div className="input-group">
                                        <label>{t('to')}</label>
                                        <input type="text" className="simple-input" placeholder="DXB" />
                                    </div>
                                    <div className="input-group">
                                        <label>{t('date')}</label>
                                        <input type="date" className="simple-input" />
                                    </div>
                                </div>
                                <div className="input-row mt-4">
                                    <div className="input-group">
                                        <label>{t('trip_2_from')}</label>
                                        <input type="text" className="simple-input" placeholder="DXB" />
                                    </div>
                                    <div className="input-group">
                                        <label>{t('to')}</label>
                                        <input type="text" className="simple-input" placeholder="LHR" />
                                    </div>
                                    <div className="input-group">
                                        <label>{t('date')}</label>
                                        <input type="date" className="simple-input" />
                                    </div>
                                </div>
                                <button className="text-blue-400 text-sm mt-2 flex items-center gap-1 hover:text-blue-300">
                                    + {t('add_another_trip')}
                                </button>
                            </div>
                        </div>
                    ) : (
                        <>
                            <div className="input-row">
                                <div className="input-group">
                                    <label>{t('from_airport_city')}</label>
                                    <input
                                        type="text"
                                        className="simple-input"
                                        placeholder={t('origin_placeholder')}
                                        value={searchParams.origin}
                                        onChange={(e) => setSearchParams({ ...searchParams, origin: e.target.value })}
                                    />
                                </div>
                                <div className="input-group">
                                    <label>{t('to_airport_city')}</label>
                                    <input
                                        type="text"
                                        className="simple-input"
                                        placeholder={t('destination_placeholder')}
                                        value={searchParams.destination}
                                        onChange={(e) => setSearchParams({ ...searchParams, destination: e.target.value })}
                                    />
                                </div>
                            </div>

                            <div className="input-row">
                                <div className="input-group">
                                    <label>{t('departure_date')}</label>
                                    <input
                                        type="date"
                                        className="simple-input"
                                        value={searchParams.departureDate}
                                        onChange={(e) => setSearchParams({ ...searchParams, departureDate: e.target.value })}
                                    />
                                </div>

                                {tripType === 'round-trip' && (
                                    <div className="input-group">
                                        <label>{t('return_date')}</label>
                                        <input
                                            type="date"
                                            className="simple-input"
                                            value={searchParams.returnDate}
                                            onChange={(e) => setSearchParams({ ...searchParams, returnDate: e.target.value })}
                                        />
                                    </div>
                                )}
                            </div>
                        </>
                    )}

                    <div className="input-row">
                        <div className="input-group">
                            <label>{t('passengers')}</label>
                            <input
                                type="number"
                                className="simple-input"
                                min="1"
                                max="9"
                                value={searchParams.adults}
                                onChange={(e) => setSearchParams({ ...searchParams, adults: parseInt(e.target.value) || 1 })}
                            />
                        </div>
                        <div className="input-group">
                            <label>{t('cabin_class')}</label>
                            <select
                                className="simple-input"
                                value={searchParams.cabinClass}
                                onChange={(e) => setSearchParams({ ...searchParams, cabinClass: e.target.value as any })}
                            >
                                <option value="ECONOMY">{t('economy')}</option>
                                <option value="BUSINESS">{t('business')}</option>
                                <option value="FIRST">{t('first')}</option>
                            </select>
                        </div>
                    </div>

                    <button className="btn btn-primary w-full mt-4" onClick={handleSearch} disabled={isLoading}>
                        {isLoading ? <Loader className="animate-spin" /> : <Search size={20} />}
                        {t('search_flights_btn')}
                    </button>
                </div>

                {/* أزرار البحث الجديدة */}
                <div className="search-buttons">
                    <button
                        className="search-btn-option smart-btn"
                        onClick={() => setShowSmartSearchModal(true)}
                        disabled={isLoading}
                    >
                        <Sparkles size={24} />
                        <div className="btn-text">
                            <strong>{t('smart_search_btn')}</strong>
                            <span>{t('smart_search_desc')}</span>
                        </div>
                    </button>

                    <button
                        className="search-btn-option sniper-btn"
                        onClick={() => setShowSniperModal(true)}
                        disabled={isLoading}
                    >
                        <Target size={24} />
                        <div className="btn-text">
                            <strong>{t('flight_sniper_btn')}</strong>
                            <span>{t('flight_sniper_desc')}</span>
                        </div>
                    </button>

                    <button
                        className="search-btn-option monitor-btn"
                        onClick={() => setShowMonitorModal(true)}
                        disabled={isLoading}
                    >
                        <Bell size={24} />
                        <div className="btn-text">
                            <strong>{t('price_monitor_btn')}</strong>
                            <span>{t('price_monitor_desc')}</span>
                        </div>
                    </button>
                </div>
            </div>

            {/* مودال البحث الذكي */}
            {showSmartSearchModal && (
                <div className="modal-overlay" onClick={() => setShowSmartSearchModal(false)}>
                    <div className="modal-content glass-card" onClick={(e) => e.stopPropagation()}>
                        <div className="modal-header">
                            <Sparkles size={24} className="text-purple-400" />
                            <h3>{t('smart_search')}</h3>
                        </div>

                        <div className="filter-section">
                            <label>{t('write_request_detail')}</label>
                            <textarea
                                className="simple-input smart-textarea"
                                placeholder={t('smart_search_placeholder')}
                                value={smartQuery}
                                onChange={(e) => setSmartQuery(e.target.value)}
                                rows={4}
                            />
                        </div>

                        <div className="modal-actions">
                            <button className="btn btn-secondary" onClick={() => setShowSmartSearchModal(false)}>
                                {t('cancel')}
                            </button>
                            <button className="btn btn-primary" onClick={handleSmartSearch}>
                                <MessageSquare size={18} />
                                {t('search_for_me')}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* مودال مراقبة الأسعار */}
            {showMonitorModal && (
                <div className="modal-overlay" onClick={() => setShowMonitorModal(false)}>
                    <div className="modal-content glass-card monitor-modal-wide" onClick={(e) => e.stopPropagation()}>
                        <div className="modal-header">
                            <Bell size={24} className="text-yellow-400" />
                            <h3>{t('monitor_title')}</h3>
                        </div>

                        {/* Stats Row */}
                        <div className="monitor-stats-row mb-6">
                            <div className="stat-card">
                                <span className="stat-value text-blue-400">2</span>
                                <span className="stat-label">{t('active_alerts')}</span>
                            </div>
                            <div className="stat-card">
                                <span className="stat-value text-green-400">0</span>
                                <span className="stat-label">{t('target_reached')}</span>
                            </div>
                            <div className="stat-card">
                                <span className="stat-value text-purple-400">2</span>
                                <span className="stat-label">{t('monitoring')}</span>
                            </div>
                        </div>

                        <div className="monitor-content-grid">
                            {/* Add New Form */}
                            <div className="add-monitor-section glass-panel p-4 rounded-xl border border-white/10">
                                <h4 className="text-white mb-4 text-sm font-bold flex items-center gap-2">
                                    <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                                    {t('add_alert')}
                                </h4>
                                <p className="modal-desc text-right mb-4 text-xs">احصل على إشعار فوري عندما ينخفض السعر.</p>

                                <div className="filter-section">
                                    <label className="text-xs">{t('route')}</label>
                                    <div className="p-3 bg-white/10 rounded-lg text-center text-sm font-bold">
                                        {searchParams.origin || '---'} ✈️ {searchParams.destination || '---'}
                                    </div>
                                </div>

                                <div className="filter-section">
                                    <label className="text-xs">{t('target_price')}</label>
                                    <input
                                        type="number"
                                        className="simple-input text-sm"
                                        placeholder="مثال: 1000"
                                    />
                                </div>

                                <button className="btn btn-primary monitor-action-btn w-full justify-center mt-2" onClick={handleMonitorSubmit}>
                                    <Bell size={16} />
                                    {t('create_alert')}
                                </button>
                            </div>

                            {/* Active Monitors List */}
                            <div className="active-monitors-list">
                                <h4 className="text-white mb-3 text-sm font-bold opacity-80">{t('current_alerts')}</h4>

                                {/* Mock Card 1 */}
                                <div className="monitor-card glass-panel p-3 rounded-xl border border-white/10 mb-3 relative overflow-hidden">
                                    <div className="flex justify-between items-start mb-2">
                                        <h5 className="font-bold text-white">JED → DXB</h5>
                                        <button className="text-red-400 hover:text-red-300"><span className="text-xs">🗑️</span></button>
                                    </div>
                                    <div className="flex justify-between items-end">
                                        <div className="text-right">
                                            <span className="text-xs text-gray-400 block">{t('current_price')}</span>
                                            <span className="text-blue-400 font-bold">890 SAR</span>
                                        </div>
                                        <div className="text-left">
                                            <span className="text-xs text-gray-400 block">{t('target_price')}</span>
                                            <span className="text-green-400 font-bold">750 SAR</span>
                                        </div>
                                    </div>
                                    <div className="mt-2 pt-2 border-t border-white/5 flex justify-between items-center">
                                        <span className="text-xs text-yellow-500 bg-yellow-500/10 px-2 py-1 rounded">أعلى بـ 18.7% ↗</span>
                                        <span className="text-[10px] text-gray-500">منذ 0 ساعة</span>
                                    </div>
                                </div>

                                {/* Mock Card 2 */}
                                <div className="monitor-card glass-panel p-3 rounded-xl border border-white/10 mb-3 relative overflow-hidden">
                                    <div className="flex justify-between items-start mb-2">
                                        <h5 className="font-bold text-white">RUH → JED</h5>
                                        <button className="text-red-400 hover:text-red-300"><span className="text-xs">🗑️</span></button>
                                    </div>
                                    <div className="flex justify-between items-end">
                                        <div className="text-right">
                                            <span className="text-xs text-gray-400 block">السعر الحالي</span>
                                            <span className="text-blue-400 font-bold">350 SAR</span>
                                        </div>
                                        <div className="text-left">
                                            <span className="text-xs text-gray-400 block">المستهدف</span>
                                            <span className="text-green-400 font-bold">300 SAR</span>
                                        </div>
                                    </div>
                                    <div className="mt-2 pt-2 border-t border-white/5 flex justify-between items-center">
                                        <span className="text-xs text-yellow-500 bg-yellow-500/10 px-2 py-1 rounded">أعلى بـ 16.7% ↗</span>
                                        <span className="text-[10px] text-gray-500">منذ 0 ساعة</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="modal-actions mt-4">
                            <button className="btn btn-secondary w-full" onClick={() => setShowMonitorModal(false)}>
                                {t('close')}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* مودال صائد الرحلات */}
            {showSniperModal && (
                <div className="modal-overlay" onClick={() => setShowSniperModal(false)}>
                    <div className="modal-content glass-card" onClick={(e) => e.stopPropagation()}>
                        <div className="modal-header">
                            <Target size={24} className="text-red-400" />
                            <h3>{t('flight_sniper')}</h3>
                        </div>

                        <p className="modal-desc">{t('sniper_description')}</p>

                        <div className="input-row">
                            <div className="filter-section w-half">
                                <label>{t('from')}</label>
                                <input
                                    type="text"
                                    className="simple-input"
                                    placeholder="JED"
                                    value={sniperParams.origin}
                                    onChange={(e) => setSniperParams({ ...sniperParams, origin: e.target.value.toUpperCase() })}
                                />
                            </div>
                            <div className="filter-section w-half">
                                <label>{t('to')}</label>
                                <input
                                    type="text"
                                    className="simple-input"
                                    placeholder="RUH"
                                    value={sniperParams.destination}
                                    onChange={(e) => setSniperParams({ ...sniperParams, destination: e.target.value.toUpperCase() })}
                                />
                            </div>
                        </div>

                        <div className="filter-section">
                            <label>{t('max_price')}</label>
                            <input
                                type="number"
                                className="simple-input"
                                placeholder="1000"
                                value={sniperParams.maxPrice}
                                onChange={(e) => setSniperParams({ ...sniperParams, maxPrice: parseInt(e.target.value) })}
                            />
                        </div>

                        <div className="filter-section">
                            <label>{t('search_frequency')}</label>
                            <select
                                className="simple-input"
                                value={sniperParams.frequencyMinutes}
                                onChange={(e) => setSniperParams({ ...sniperParams, frequencyMinutes: parseInt(e.target.value) })}
                            >
                                <option value="15">{t('every_15_min')}</option>
                                <option value="30">{t('every_30_min')}</option>
                                <option value="60">{t('every_hour')}</option>
                                <option value="360">{t('every_6_hours')}</option>
                            </select>
                        </div>

                        <div className="modal-actions">
                            <button className="btn btn-secondary" onClick={() => setShowSniperModal(false)}>
                                إلغاء
                            </button>
                            <button className="btn btn-primary sniper-action-btn" onClick={handleSniperSubmit}>
                                <Target size={18} />
                                {t('start_hunting')}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {parsedIntent && (
                <div className="intent-message glass-card animate-fade-in">
                    <Sparkles size={16} className="inline-icon" />
                    <span>{parsedIntent}</span>
                </div>
            )}

            {error && (
                <div className="error-message glass-card animate-fade-in">
                    <p>⚠️ {error}</p>
                </div>
            )}

            {successMessage && (
                <div className="success-message glass-card animate-fade-in">
                    <Bell size={20} />
                    <p>{successMessage}</p>
                </div>
            )}

            {results.length > 0 && (
                <div className="results-container">
                    <h2>{t('search_results')} ({results.length})</h2>
                    <div className="results-grid">
                        {results.map((offer) => (
                            <div key={offer.id} className="flight-card glass-card animate-fade-in">
                                <div className="flight-header">
                                    <div className="price">
                                        {offer.price.total} {offer.price.currency}
                                    </div>
                                    <button className="btn btn-sm btn-primary">{t('book')}</button>
                                </div>
                                <div className="flight-segments">
                                    {offer.itineraries[0].segments.map((segment, idx) => (
                                        <div key={idx} className="segment">
                                            <span>{segment.departure.iataCode}</span>
                                            <ArrowRight size={16} />
                                            <span>{segment.arrival.iataCode}</span>
                                            <span className="text-xs text-gray-400">({segment.carrierCode} {segment.number})</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};
